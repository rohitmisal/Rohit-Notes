package com.ait.login.service;

public interface CustomerLoginService {
	boolean  validateCustomer(String userName, String password);
}

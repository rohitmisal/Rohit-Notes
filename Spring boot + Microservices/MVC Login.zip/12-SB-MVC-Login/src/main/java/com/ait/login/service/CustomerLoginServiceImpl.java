package com.ait.login.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ait.login.entity.CustomerLogin;
import com.ait.login.repository.CustomerLoginRepository;

@Service
public class CustomerLoginServiceImpl implements CustomerLoginService {
	
	@Autowired
	CustomerLoginRepository repo;

	@Override
	public boolean validateCustomer(String userName, String password) {
		Optional<CustomerLogin> opt = repo.findById(userName);
		
		if(opt.isPresent()) {
			CustomerLogin login = opt.get();
			if(login.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}

}

package com.ait.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ait.login.service.CustomerLoginService;

@Controller
public class CustomerLoginController {
	
	@Autowired
	CustomerLoginService service;
	
	@GetMapping(value = "/login")
	public String getLoginPage() {
		return "Login";
	}
	
	@PostMapping(value = "/authenticate")
	public String authentication(@RequestParam String userName, @RequestParam String password, Model model) {
		
		boolean flag = service.validateCustomer(userName, password);
		if(flag == true) {
			model.addAttribute("userName", userName);
			model.addAttribute("LoginTime", java.time.LocalDateTime.now());
			return "Success";
		}
		else {
			model.addAttribute("message",  "Bad Credentials, Try again");
			return "Login";
		}
		
	}

}

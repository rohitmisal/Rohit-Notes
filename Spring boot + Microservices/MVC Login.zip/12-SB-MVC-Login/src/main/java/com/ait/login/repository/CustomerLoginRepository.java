package com.ait.login.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ait.login.entity.CustomerLogin;

public interface CustomerLoginRepository extends JpaRepository<CustomerLogin, String> {

}
